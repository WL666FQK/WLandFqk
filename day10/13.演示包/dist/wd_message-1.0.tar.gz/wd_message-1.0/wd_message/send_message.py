# Author: 王璐
# Date: 2024/10/17


def send():
    print('I am send')